package automation.Nimap_Infotech;


import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class set
{
	WebDriver driver;

@BeforeTest
	 public void set()
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Admin\\Arati_Testing\\Nimap_Infotech\\resources\\chromedriver.exe");
		 driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://testffc.nimapinfotech.com/dashboard");
		driver.manage().timeouts().implicitlyWait(3,TimeUnit.SECONDS);
	}
}
