package automation.Nimap_Infotech;

import org.openqa.selenium.By;
import org.testng.annotations.Test;


public class loginprocess extends set
{
	@Test(priority=1)
	void ragistrationProcess() throws InterruptedException
	{
         driver.findElement(By.xpath("/html/body/kt-auth/div/div/div[2]/kt-login/div[1]/a")).click();
         driver.findElement(By.xpath("/html/body/kt-auth/div/div/div[2]/kt-register/div/div/form/div[1]/mat-form-field/div/div[1]/div/input")).sendKeys("aratii");
         driver.findElement(By.xpath("/html/body/kt-auth/div/div/div[2]/kt-register/div/div/form/div[3]/mat-form-field/div/div[1]/div/input")).sendKeys("1234567890");
        
         driver.findElement(By.xpath("/html/body/kt-auth/div/div/div[2]/kt-register/div/div/form/div[4]/mat-form-field/div/div[1]/div/input")).sendKeys("waghmarearati6@gmail.com");
         //driver.findElement(By.xpath("/html/body/kt-auth/div/div/div[2]/kt-register/div/div/form/kt-captcha/div/div/form/input")).sendKeys("E5DIL3");
        Thread.sleep(10000);
         driver.findElement(By.id("kt_login_signin_submit")).click();
         //driver.close();
         
         
      }
	@Test(priority=2)
	void signIn() throws InterruptedException
	{
		Thread.sleep(10000);
		//driver.findElement(By.xpath("/html/body/kt-auth/div/div/div[2]/kt-reset-password/div/div/form/div[1]/mat-form-field/div/div[1]/div/input")).sendKeys("7885");

		driver.findElement(By.xpath("/html/body/kt-auth/div/div/div[2]/kt-reset-password/div/div/form/div[2]/mat-form-field/div/div[1]/div/input")).sendKeys("prajwal");
         driver.findElement(By.xpath("//input[@placeholder='Confirm Password']")).sendKeys("prajwal@123");
         //driver.findElement(By.id("kt_login_signin_submit")).click();
         driver.findElement(By.xpath("/html/body/kt-auth/div/div/div[2]/kt-reset-password/div/div/form/div[4]/button[1]")).click();
	}
	
	


	
}
